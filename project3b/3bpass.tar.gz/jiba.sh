#!/bin/bash -e

if [ ! -s temp.txt ]
then
    echo fuck you
fi
